import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Font;

public class StartTheQuiz {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartTheQuiz window = new StartTheQuiz();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StartTheQuiz() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 240, 245));
		frame.setBounds(0, 0, 1350, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(476, 24, 682, 532);
		frame.getContentPane().add(lblNewLabel);
		ImageIcon icon = new ImageIcon(this.getClass().getResource("/stiming.gif"));
		lblNewLabel.setIcon(icon);
		
		JButton btnstart = new JButton("");
		Image index = new ImageIcon(this.getClass().getResource("/startsurvey.png")).getImage();
		btnstart.setIcon(new ImageIcon(index));
		btnstart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				productpage ty = new productpage();
				ty.abhi();
		}
		});
		btnstart.setBounds(601, 620, 632, 84);
		frame.getContentPane().add(btnstart);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(20, 81, 290, 212);
		frame.getContentPane().add(lblNewLabel_1);
		ImageIcon im = new ImageIcon(this.getClass().getResource("/images.jfif"));
		lblNewLabel_1.setIcon(im);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setBounds(20, 354, 336, 399);
		frame.getContentPane().add(lblNewLabel_3);
		ImageIcon img = new ImageIcon(this.getClass().getResource("/manfeed.png"));
		lblNewLabel_3.setIcon(img);
		
		JLabel lblNewLabel_2 = new JLabel("Q");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_2.setBounds(20, 22, 29, 49);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("VOID");
		lblNewLabel_4.setForeground(new Color(34, 139, 34));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_4.setBounds(54, 24, 74, 49);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("@copyright");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(1236, 728, 90, 25);
		frame.getContentPane().add(lblNewLabel_5);
	}
}
