


import java.awt.event.ActionEvent;



import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

class OnlineTest extends JFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;

	JLabel label;
	JRadioButton radioButton[] = new JRadioButton[5];
	JButton btnNext, btnBookmark;
	ButtonGroup bg;
	int count = 0, current = 0, x = 1, y = 1, now = 0;
	int m[] = new int[10];

	// create jFrame with radioButton and JButton
	OnlineTest(String s) {
		super(s);
		label = new JLabel();
		add(label);
		bg = new ButtonGroup();
		for (int i = 0; i < 5; i++) {
			radioButton[i] = new JRadioButton();
			add(radioButton[i]);
			bg.add(radioButton[i]);
		}
		btnNext = new JButton("Next");
		btnBookmark = new JButton("Bookmark");
		btnNext.addActionListener(this);
		btnBookmark.addActionListener(this);
		add(btnNext);
		add(btnBookmark);
		set();
		label.setBounds(30, 40, 450, 20);
		radioButton[0].setBounds(50, 80, 200, 20);
//		radioButton[0].setBounds(50, 80, 450, 20);
		radioButton[1].setBounds(50, 110, 200, 20);
		radioButton[2].setBounds(50, 140, 200, 20);
		radioButton[3].setBounds(50, 170, 200, 20);
		radioButton[4].setBounds(50,200,200,20);
		btnNext.setBounds(100, 240, 100, 30);
		btnBookmark.setBounds(270, 240, 100, 30);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		setLocation(250, 100);
		setVisible(true);
		setSize(800, 400);
	}

	// handle all actions based on event
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNext) {
			if (check())
				count = count + 1;
			current++;
			set();
			if (current == 9) {
				btnNext.setEnabled(false);
				btnBookmark.setText("Submit");
			}
		}
		if (e.getActionCommand().equals("Bookmark")) {
			JButton bk = new JButton("Bookmark" + x);
			bk.setBounds(480, 20 + 30 * x, 100, 30);
			add(bk);
			bk.addActionListener(this);
			m[x] = current;
			x++;
			current++;
			set();
			if (current == 9)
				btnBookmark.setText("Submit");
			setVisible(false);
			setVisible(true);
		}
		for (int i = 0, y = 1; i < x; i++, y++) {
			if (e.getActionCommand().equals("Bookmark" + y)) {
				if (check())
					count = count + 1;
				now = current;
				current = m[y];
				set();
				((JButton) e.getSource()).setEnabled(false);
				current = now;
			}
		}

		if (e.getActionCommand().equals("Submit")) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userlogin","root","Abhiii@12345");
//				PreparedStatement ps = conn.prepareStatement("INSERT INTO 'userlogin'.'logindetails' ('USERNAME') VALUES ('James Bond');");
//				PreparedStatement ab = conn.prepareStatement("INSERT INTO 'userlogin'.'logindetails' ('PASSWORD') VALUES ('James@54321');");
//				Statement stmt = conn.createStatement();
//				String sql = "select * from registrationdetails where  Name='"+NAME.getText()+"'  Surname='"+SURNAME.getText()+"' Gender='"+GENDER.getText().toString()+"' Birth='"+DOB.getText().toString()+"',"
//						+ "  Email='"+EMAIL.getText().toString()+"'  Mobile='"+MOBILE.getText().toString()+"' Create Username='"+USER.getText().toString()+"'  Create Password='"+PASS.getText().toString()+"'";
//				
//				ResultSet rs = stmt.executeQuery(sql);
				PreparedStatement ps = conn.prepareStatement("insert into quizpart(Question a,Question b,Question c,Question d,Question e,Question f,Question g,Question h,Question i,Question j) values(1,?,?,?,?,?,?,?,?,?);");
						ps.setString(0, label.getText());
				ps.setString(1, label.getText());
				ps.setString(2, label.getText());
				ps.setString(3, label.getText());
				ps.setString(4, label.getText());
				ps.setString(5, label.getText());
				ps.setString(6, label.getText());
				ps.setString(7, label.getText());
				ps.setString(8, label.getText());
				ps.setString(9, label.getText());
				int x = ps.executeUpdate();
								
				
				
//				if(rs.next())
//					JOptionPane.showMessageDialog(null, "Registration  Successful");
//				else
//					JOptionPane.showMessageDialog(null, "Invalid Username or Password");
//				conn.close();
			} catch(Exception e1) {
				System.out.println(e1);
			}
			if (check())
//				count = count + 1;
			current++;
			JOptionPane.showMessageDialog(this, "Thanks for the survey" );
			System.exit(0);
		}
	}

	// SET Questions with options
	void set() {
		radioButton[4].setSelected(true);
		if (current == 0) {
			label.setText("Q1: I had no trouble walking long distances while wearing these shoes.       ");
			radioButton[0].setText("1 rating");
			radioButton[1].setText("2 ratings");
			radioButton[2].setText("3 ratings");
			radioButton[3].setText("4 ratings");
			radioButton[4].setText("5 ratings");
		}
		if (current == 1) {
			label.setText("Q2: I felt very stylish whenever I put these shoes on      ");
			radioButton[0].setText("1 ratings");
			radioButton[1].setText("2 ratings");
			radioButton[2].setText("3 ratings");
			radioButton[3].setText("4 ratings");
			radioButton[4].setText("5 ratings");
		}
		if (current == 2) {
			label.setText("Q3: The shoe's sole provided an adequate amount of slip resistance when walking on slick surfaces.");
			radioButton[0].setText("Agree");
			radioButton[1].setText("Disagree");
			radioButton[2].setText("little bit");
			radioButton[3].setText("Highly agree");
			radioButton[4].setText("Highly disagree");
		}
		if (current == 3) {
			label.setText("Q4:I am confident in the quality of Q Void shoes.");
			radioButton[0].setText("1 rating");
			radioButton[1].setText("2 ratings");
			radioButton[2].setText("3 ratings");
			radioButton[3].setText("4 ratings");
			radioButton[4].setText("5 ratings");
		}
		if (current == 4) {
			label.setText("Que5: I plan to buy these shoes for friends or family members.");
			radioButton[0].setText("Agree");
			radioButton[1].setText("Highly agree");
			radioButton[2].setText("May be");
			radioButton[3].setText("Disagree");
			radioButton[4].setText("Highly disagree");
		}
		if (current == 5) {
			label.setText("Que6: I would recommend these shoes to others . ");
			radioButton[0].setText("Totally agree");
			radioButton[1].setText("Totally Disagree");
			radioButton[2].setText("No Way");
			radioButton[3].setText("May be");
			radioButton[4].setText("will think");
		}
		if (current == 6) {
			label.setText("Que7: Approximately how many hours a day did you wear these shoes?");
			radioButton[0].setText("2");
			radioButton[1].setText("4");
			radioButton[2].setText("6");
			radioButton[3].setText("1");
			radioButton[4].setText("none");
		}
		if (current == 7) {
			label.setText("Que8: I am more likely to buy other styles of Q Void shoes than I was before.  ");
			radioButton[0].setText("1");
			radioButton[1].setText("2");
			radioButton[2].setText("3");
			radioButton[3].setText("4");
			radioButton[4].setText("5");
		}
		if (current == 8) {
			label.setText("Que9: what athletic activities did you perform while wearing them?");
			radioButton[0].setText("running");
			radioButton[1].setText("Cricket");
			radioButton[2].setText("Jogging");
			radioButton[3].setText("other");
			radioButton[4].setText("none");
		}
		if (current == 9) {
			label.setText("Q10: Are you agree with our product?");
			radioButton[0].setText("Agree");
			radioButton[1].setText("Disagree");
			radioButton[2].setText("i don't know");
			radioButton[3].setText("Maybe");
			radioButton[4].setText("superb");
		}
		label.setBounds(30, 40, 600, 20);
		for (int i = 0, j = 0; i <= 90; i += 30, j++)
			radioButton[j].setBounds(50, 80 + i, 250, 20);
	}

	// declare right answers.
	boolean check() {
		if (current == 0)
			return (radioButton[1].isSelected());
		if (current == 1)
			return (radioButton[1].isSelected());
		if (current == 2)
			return (radioButton[0].isSelected());
		if (current == 3)
			return (radioButton[2].isSelected());
		if (current == 4)
			return (radioButton[0].isSelected());
		if (current == 5)
			return (radioButton[0].isSelected());
		if (current == 6)
			return (radioButton[1].isSelected());
		if (current == 7)
			return (radioButton[2].isSelected());
		if (current == 8)
			return (radioButton[0].isSelected());
		if (current == 9)
			return (radioButton[0].isSelected());
		return false;
	}

	public static void newrunner() {
		new OnlineTest("Shoes Survey");
	}

}