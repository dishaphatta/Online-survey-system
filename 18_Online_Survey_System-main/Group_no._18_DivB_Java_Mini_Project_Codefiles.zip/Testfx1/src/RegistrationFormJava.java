import java.awt.EventQueue;




import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import com.toedter.calendar.JDateChooser;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;

public class RegistrationFormJava {

	private JFrame frame;
	private JTextField NAME;
	private JTextField SURNAME;
	private JTextField EMAIL;
	private JTextField MOBILE;
	private JTextField USER;
	private JPasswordField PASS;
	
	private JTextField textField;
	private JDateChooser dateChooser;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void radar() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistrationFormJava window = new RegistrationFormJava();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RegistrationFormJava() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(0, 0, 1251, 770);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(255, 255, 255));
		panel.setBackground(new Color(240, 248, 255));
		panel.setBorder(new LineBorder(SystemColor.activeCaption, 13));
		panel.setBounds(10, 10, 1217, 713);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(22, 22, 206, 213);
		panel.add(lblNewLabel);
		ImageIcon icon = new ImageIcon(this.getClass().getResource("/Logo-Small.png"));
		lblNewLabel.setIcon(icon);
		
		JLabel lblNewLabel_1 = new JLabel("Registration Form");
		lblNewLabel_1.setBounds(412, 22, 552, 81);
		lblNewLabel_1.setForeground(Color.DARK_GRAY);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 56));
		panel.add(lblNewLabel_1);
		
		JLabel NAMELabel = new JLabel("NAME ");
		NAMELabel.setBounds(368, 169, 104, 40);
		NAMELabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		panel.add(NAMELabel);
		
		NAME = new JTextField();
		NAME.setFont(new Font("Tahoma", Font.ITALIC, 16));
		NAME.setBounds(533, 175, 196, 36);
		panel.add(NAME);
		NAME.setColumns(10);
		
		JLabel SURNAMELabel = new JLabel("SURNAME ");
		SURNAMELabel.setBounds(322, 244, 150, 36);
		SURNAMELabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		panel.add(SURNAMELabel);
		
		SURNAME = new JTextField();
		SURNAME.setFont(new Font("Tahoma", Font.ITALIC, 16));
		SURNAME.setBounds(533, 248, 196, 36);
		panel.add(SURNAME);
		SURNAME.setColumns(10);
		
		JLabel GENDERLabel = new JLabel("GENDER (M/F)");
		GENDERLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		GENDERLabel.setBounds(287, 310, 185, 40);
		panel.add(GENDERLabel);
		
		JLabel DOBLabel = new JLabel("DOB (dd/mm/yyyy)");
		DOBLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		DOBLabel.setBounds(305, 374, 243, 40);
		panel.add(DOBLabel);
		
		JLabel EMAILlABEL = new JLabel("EMAIL ");
		EMAILlABEL.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		EMAILlABEL.setBounds(336, 463, 104, 36);
		panel.add(EMAILlABEL);
		
		EMAIL = new JTextField();
		EMAIL.setFont(new Font("Tahoma", Font.ITALIC, 15));
		EMAIL.setBounds(479, 463, 261, 36);
		panel.add(EMAIL);
		EMAIL.setColumns(10);
		
		JLabel MOBILELabel = new JLabel("MOBILE ");
		MOBILELabel.setForeground(new Color(0, 0, 0));
		MOBILELabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		MOBILELabel.setBounds(309, 533, 131, 36);
		panel.add(MOBILELabel);
		
		MOBILE = new JTextField();
		MOBILE.setFont(new Font("Tahoma", Font.BOLD, 15));
		MOBILE.setBounds(467, 540, 249, 36);
		panel.add(MOBILE);
		MOBILE.setColumns(10);
		
		JLabel USERLabel = new JLabel("USERNAME");
		USERLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		USERLabel.setBounds(761, 175, 185, 40);
		panel.add(USERLabel);
		
		USER = new JTextField();
		USER.setFont(new Font("Tahoma", Font.ITALIC, 15));
		USER.setBounds(956, 177, 237, 36);
		panel.add(USER);
		USER.setColumns(10);
		
		JLabel PASSLabel = new JLabel("PASSWORD");
		PASSLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		PASSLabel.setBounds(761, 251, 185, 36);
		panel.add(PASSLabel);
		
		PASS = new JPasswordField();
		PASS.setBounds(956, 251, 237, 36);
		panel.add(PASS);
		
		JButton REGISTER = new JButton("REGISTER");
		REGISTER.addActionListener(new ActionListener() {
			
		
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
//				
//				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userlogin","root","Abhiii@12345");
					
					PreparedStatement ps = conn.prepareStatement("insert into registrationdetails(idRegistrationdetails,Name,Surname,Gender,Birth,Email,Mobile,USERNAME,PASSWORD) values(1,?,?,?,?,?,?,?,?);");
							ps.setString(1, NAME.getText());
					ps.setString(2, SURNAME.getText());
					
					ps.setString(3, textField.getText());
					
					
					
					
			        ps.setString(4, textField_1.getText() );
			       
		                
					ps.setString(5, EMAIL.getText());
					ps.setString(6, MOBILE.getText());
					ps.setString(7, USER.getText());
					ps.setString(8, PASS.getText());
					int x = ps.executeUpdate();
					if (x>0)
						JOptionPane.showMessageDialog(null, "Registration Successful");
						else
							JOptionPane.showMessageDialog(null, "Invalid Username or Password");
					
					
					

				} catch(Exception e1) {
					System.out.println(e1);
				}
			
			}
		});
		REGISTER.setFont(new Font("Tahoma", Font.BOLD, 24));
		REGISTER.setBounds(1008, 341, 185, 47);
		panel.add(REGISTER);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBounds(22, 378, 289, 313);
		panel.add(lblNewLabel_2);
		ImageIcon img = new ImageIcon(this.getClass().getResource("/manfeed.png"));
		lblNewLabel_2.setIcon(img);
		
		JButton btnNewButton = new JButton("Back To Login");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginPage ps = new LoginPage();
				ps.main(null);
				
		}
		});
		btnNewButton.setBounds(772, 342, 206, 46);
		panel.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(533, 321, 196, 31);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(552, 384, 196, 34);
		panel.add(textField_1);
		textField_1.setColumns(10);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
	public JDateChooser getDate() {
		
		return dateChooser;
		
	}
}
