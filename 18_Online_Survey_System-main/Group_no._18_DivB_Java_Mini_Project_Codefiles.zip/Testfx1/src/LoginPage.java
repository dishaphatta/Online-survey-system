import java.awt.EventQueue;







import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
public class LoginPage {

	private JFrame frame;
	private JTextField USER;
	private JPasswordField PASS;

	/**
	 * Launch the application.
	 */
	public static void main(String[]args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage window = new LoginPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(100, 100, 1257, 749);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(10, 10, 1223, 692);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(250, 10, 963, 672);
		panel_1.setBackground(SystemColor.activeCaption);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		USER = new JTextField();
		USER.setBounds(633, 358, 299, 33);
		USER.setBackground(SystemColor.info);
		panel_1.add(USER);
		USER.setColumns(10);
		
		PASS = new JPasswordField();
		PASS.setBounds(633, 446, 299, 33);
		PASS.setBackground(SystemColor.info);
		panel_1.add(PASS);
		
		JLabel lblNewLabel = new JLabel("USERNAME");
		lblNewLabel.setBounds(419, 358, 149, 33);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setBounds(419, 442, 135, 33);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel_1.add(lblNewLabel_1);
		
		JButton btnLOGIN = new JButton("LOGIN");
		btnLOGIN.setBounds(559, 532, 128, 33);
//		btnLOGIN.setBackground(SystemColor.inactiveCaption);
		btnLOGIN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
//				String un= USER.getText();
//				String pas= PASS.getText();
//				
//				if(un.equals("admin")&& pas.equals("654321")) {
//					JOptionPane.showMessageDialog(null, "Login Successful");
//					
//					
//				}
//				else {
//					JOptionPane.showMessageDialog(null, "Invalid Username or Password");
//				}
//				try {
//					Class.forName("com.mysql.cj.jdbc.Driver");
//					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userlogin","root","Abhiii@12345");
////					PreparedStatement ps = conn.prepareStatement("INSERT INTO 'userlogin'.'logindetails' ('USERNAME') VALUES ('James Bond');");
////					PreparedStatement ab = conn.prepareStatement("INSERT INTO 'userlogin'.'logindetails' ('PASSWORD') VALUES ('James@54321');");
//					Statement stmt = conn.createStatement();
//					String sql = "select * from registrationdetails where USERNAME='"+USER.getText()+"' and PASSWORD='"+PASS.getText().toString()+"'";
//					ResultSet rs = stmt.executeQuery(sql);
//					if(rs.next())
//						JOptionPane.showMessageDialog(null, "Login Successful");
//					else
//						JOptionPane.showMessageDialog(null, "Invalid Username or Password");
//					conn.close();
//				} catch(Exception e1) {
//					System.out.println(e1);
//				}
//			}
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userlogin","root","Abhiii@12345");
					
					PreparedStatement ps = conn.prepareStatement("insert into logindetails(USERNAME,PASSWORD) values(?,?);");
							
					ps.setString(1, USER.getText());
					ps.setString(2, PASS.getText());
					int x = ps.executeUpdate();
					if (x>0) 
						JOptionPane.showMessageDialog(null, "Login Successful");
						else
							JOptionPane.showMessageDialog(null, "Invalid Username or Password");
					StartTheQuiz ps1 = new StartTheQuiz();
					ps1.main(null);
					
				} catch(Exception e1) {
					System.out.println(e1);
				}
			
			}
		});
		btnLOGIN.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel_1.add(btnLOGIN);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBackground(new Color(240, 248, 255));
		lblNewLabel_2.setBounds(0, 0, 963, 672);
		panel_1.add(lblNewLabel_2);
		ImageIcon icon = new ImageIcon(this.getClass().getResource("/surveyimg.jpg"));
		lblNewLabel_2.setIcon(icon);
		
		JLabel label = new JLabel("New label");
		label.setBounds(-15, 0, 10, -4);
		panel_1.add(label);
		
		JLabel label_1 = new JLabel("New label");
		label_1.setBounds(0, 10, 10, 6);
		panel_1.add(label_1);
		
		JLabel label_2 = new JLabel("New label");
		label_2.setBounds(10, 489, 260, 162);
		panel_1.add(label_2);
		
//		JLabel lblNewLabel_5 = new JLabel("");
//		lblNewLabel_5.setBounds(10, 489, 260, 162);
//		panel_1.add(lblNewLabel_5);
//		ImageIcon list = new ImageIcon(this.getClass().getResource("/smalldani.png"));
//		lblNewLabel_5.setIcon(list);
//		
		JButton btnREGISTER = new JButton("REGISTER");
		btnREGISTER.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnREGISTER.setBounds(727, 532, 160, 30);
		lblNewLabel_2.add(btnREGISTER);
		
		JLabel lblNewLabel_7 = new JLabel("Qvoid");
		lblNewLabel_7.setBounds(785, 638, 160, 24);
		panel_1.add(lblNewLabel_7);
		btnREGISTER.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegistrationFormJava aw = new RegistrationFormJava();
				aw.radar();
				
		}
		});
		
		
		
		
//		JLabel lblNewLabel_3 = new JLabel("New label");
//		lblNewLabel_3.setBounds(10, 10, 943, 640);
//		panel_1.add(lblNewLabel_3);
//		ImageIcon img = new ImageIcon(this.getClass().getResource("/surveyimg.jpg"));
//		lblNewLabel_3.setIcon(img);
		
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(216, 191, 216));
		panel_2.setBounds(10, 10, 233, 672);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setBackground(new Color(219, 112, 147));
		lblNewLabel_3.setBounds(10, -231, 213, 673);
		panel_2.add(lblNewLabel_3);
		ImageIcon img = new ImageIcon(this.getClass().getResource("/backgroundsurvey.jpg"));
		lblNewLabel_3.setIcon(img);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setBounds(10, 10, 213, 326);
		panel_2.add(lblNewLabel_4);
		ImageIcon doc = new ImageIcon(this.getClass().getResource("/Logo-Small.png"));
		lblNewLabel_3.setIcon(doc);
		
		JButton btnNewButton = new JButton("Let's Login");
		btnNewButton.setBackground(new Color(230, 230, 250));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				StartTheQuiz ps = new StartTheQuiz();
//				ps.main(null);
//				
		}
		});
		btnNewButton.setBounds(24, 503, 177, 52);
		panel_2.add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("Hello All  !!!");
		lblNewLabel_6.setForeground(new Color(100, 149, 237));
//		public void actionPerformed(ActionEvent e) {
//			LoginPage ps = new LoginPage();
//			ps.main(null);
//			
//	}
//	});
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 24));
		
		lblNewLabel_6.setBounds(40, 451, 161, 42);
		panel_2.add(lblNewLabel_6);
		
	}
}
		
	

