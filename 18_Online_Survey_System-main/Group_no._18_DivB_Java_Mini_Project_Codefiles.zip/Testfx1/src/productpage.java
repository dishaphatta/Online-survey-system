import java.awt.BorderLayout;



import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JScrollBar;
import javax.swing.UIManager;

public class productpage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void abhi() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					productpage frame = new productpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public productpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1350, 800);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 240, 245));
		panel.setBorder(new LineBorder(SystemColor.activeCaption, 13));
		panel.setBounds(10, 10, 1304, 743);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(1080, 486, 201, 183);
		panel.add(lblNewLabel);
		ImageIcon icon = new ImageIcon(this.getClass().getResource("/Logo-Small.png"));
		lblNewLabel.setIcon(icon);
		
		JButton button_view = new JButton("");
		Image img = new ImageIcon(this.getClass().getResource("/shoesimg.png")).getImage();
		button_view.setIcon(new ImageIcon(img));
		button_view.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OnlineTest nw = OnlineTest();
				nw.newrunner();
				
		}
		});
		button_view.setBounds(302, 42, 244, 174);
	    panel.add(button_view);
	    
	    JLabel lblNewLabel_2 = new JLabel(" Take a survey for any products.........");
	    lblNewLabel_2.setForeground(new Color(0, 0, 0));
	    lblNewLabel_2.setFont(new Font("Tahoma", Font.ITALIC, 35));
	    lblNewLabel_2.setBounds(487, 266, 540, 88);
	    panel.add(lblNewLabel_2);
	    
	    JLabel lblNewLabel_3 = new JLabel("SHOES");
	    lblNewLabel_3.setForeground(new Color(0, 0, 0));
	    lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
	    lblNewLabel_3.setBounds(366, 226, 118, 50);
	    panel.add(lblNewLabel_3);
	    
	    JButton btnNewButton = new JButton("");
	    Image index = new ImageIcon(this.getClass().getResource("/hoodie.png")).getImage();
		btnNewButton.setIcon(new ImageIcon(index));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OnlineTesta su = OnlineTesta();
				su.hydra();
		}
		});
	    btnNewButton.setBounds(655, 401, 237, 228);
	    
	    panel.add(btnNewButton);
	    
	    JLabel lblNewLabel_4 = new JLabel("CLOTHING");
	    lblNewLabel_4.setForeground(new Color(0, 0, 0));
	    lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
	    lblNewLabel_4.setBounds(690, 649, 179, 44);
	    panel.add(lblNewLabel_4);
	    
	    JButton sun = new JButton("");
	    Image glass = new ImageIcon(this.getClass().getResource("/sunglass.png")).getImage();
		sun.setIcon(new ImageIcon(glass));
		sun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		}
		});
	    sun.setBounds(955, 40, 282, 162);
	    panel.add(sun);
	    
	    JLabel lblNewLabel_5 = new JLabel("SUNGLASS");
	    lblNewLabel_5.setForeground(new Color(0, 0, 0));
	    lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
	    lblNewLabel_5.setBounds(1037, 229, 179, 44);
	    panel.add(lblNewLabel_5);
	    
	    JLabel lblNewLabel_6 = new JLabel("New label");
	    lblNewLabel_6.setBackground(SystemColor.activeCaption);
	    lblNewLabel_6.setBounds(20, 392, 472, 329);
	    panel.add(lblNewLabel_6);
	    ImageIcon ours = new ImageIcon(this.getClass().getResource("/ourspro.png"));
	    lblNewLabel_6.setIcon(ours);
	    
	    JComboBox comboBox = new JComboBox();
	    comboBox.setBackground(new Color(255, 240, 245));
	    comboBox.setForeground(new Color(148, 0, 211));
	    comboBox.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 25));
	    comboBox.setModel(new DefaultComboBoxModel(new String[] {"Our Survey", "Our Products","Discounts","Top Rated"}));
	    comboBox.setBounds(20, 33, 209, 36);
	    panel.add(comboBox);
	    
	    JLabel lblNewLabel_1 = new JLabel("Q");
	    lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
	    lblNewLabel_1.setBounds(1136, 679, 29, 44);
	    panel.add(lblNewLabel_1);
	    
	    JLabel lblNewLabel_7 = new JLabel("VOID");
	    lblNewLabel_7.setForeground(new Color(34, 139, 34));
	    lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 20));
	    lblNewLabel_7.setBounds(1164, 679, 73, 50);
	    panel.add(lblNewLabel_7);
		
	}

	protected OnlineTesta OnlineTesta() {
		// TODO Auto-generated method stub
		return null;
	}

	protected OnlineTest OnlineTest() {
		// TODO Auto-generated method stub
		return null;
	}
}
